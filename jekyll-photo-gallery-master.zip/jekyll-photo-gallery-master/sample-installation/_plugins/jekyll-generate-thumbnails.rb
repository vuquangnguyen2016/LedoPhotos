#Remove the '#' to enable automatic thumbnail generation with image magick.
#See https://github.com/zroger/jekyll-minimagick for information on how to set it up on your system.
require "jekyll-minimagick"