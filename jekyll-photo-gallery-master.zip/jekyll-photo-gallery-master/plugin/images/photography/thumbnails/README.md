#README

These thumbnails can be auto-generated with imageMagick (see the main README file for a tutorial) or you can just export them
from Lightroom/Photoshop etc. in the right size.